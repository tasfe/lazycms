dp.sh.Brushes.Plain=function(){this.regexList=[]};dp.sh.Brushes.Plain.prototype=new dp.sh.Highlighter;dp.sh.Brushes.Plain.Aliases=["plain","text","txt"];
